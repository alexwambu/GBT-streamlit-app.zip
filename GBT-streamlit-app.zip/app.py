
import streamlit as st

st.set_page_config(page_title="GBT Network Dashboard", layout="wide")

st.title("🚀 GBT Network Monitoring Dashboard")
st.markdown("View mining rewards, wallet balances, and live metrics from the GBT Mainnet.")

col1, col2 = st.columns(2)

with col1:
    st.header("Live Mining Rewards")
    st.metric(label="24h Total Mined", value="1989.0927 GBT")
    st.metric(label="Current Difficulty", value="Fixed")
    st.progress(75)

with col2:
    st.header("Wallet Stats")
    wallet = st.text_input("Enter Wallet Address")
    if wallet:
        st.success(f"Balance: 1,273.00 GBT")
        st.info("Gas fee: 0.001 GBT | Mining: Free")

st.markdown("---")
st.markdown("📡 Node Status: `ONLINE` | 🌐 Mainnet Active")
